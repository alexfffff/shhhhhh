package edu.upenn.cis.nets212.hw3.livy;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ExecutionException;

import org.apache.livy.LivyClient;
import org.apache.livy.LivyClientBuilder;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.BatchWriteItemOutcome;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Index;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.ScanOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.TableWriteItems;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.utils.NameMap;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.WriteRequest;

import edu.upenn.cis.nets212.config.Config;
import scala.Tuple2;

public class NewsRanksLivy {
	
	public static void main(String[] args) throws IOException, URISyntaxException, InterruptedException, ExecutionException {
		
		LivyClient client = new LivyClientBuilder()
				  .setURI(new URI("http://ec2-54-197-123-173.compute-1.amazonaws.com:8998/"))
				  .build();

		try {
			String jar = "target/nets212-hw3-0.0.1-SNAPSHOT.jar";
			
		  System.out.printf("Uploading %s to the Spark context...\n", jar);
		  client.uploadJar(new File(jar)).get();
		  
		  String sourceFile = Config.BIGGER_SOCIAL_NET_PATH;//.SOCIAL_NET_PATH;
		  
		  
		  
		  System.out.printf("Running SocialRankJob with %s as its input...\n", sourceFile);

		  AmazonDynamoDB clientd = AmazonDynamoDBClientBuilder.standard().build();
		  DynamoDB db = new DynamoDB(clientd);
		  
		  NewsRanksJob x = new NewsRanksJob();
		  
		  ArrayList<String> singlelist = new ArrayList<String>();
		  ArrayList<String> singlelist2 = new ArrayList<String>();
		  ItemCollection<QueryOutcome> itemsq;
		  ItemCollection<ScanOutcome> items = db.getTable("friends").scan(null, "yourUsername, friendUsername", null, null);
		  Iterator<Item> friendsi = items.iterator();
		  ArrayList<Tuple2<String,String>> list = new ArrayList<Tuple2<String,String>>();
		  while (friendsi.hasNext()) {
				Item temp = friendsi.next();
				list.add(new Tuple2<String,String>("u:" + temp.getString("yourUsername"), "u:" + temp.getString("friendUsername")));
				list.add(new Tuple2<String,String>(temp.getString("yourUsername"), temp.getString("friendUsername")));
		  }
		  x.friends = list;
		  HashMap<String,String> catmap= new HashMap<String,String>();

		  
		  
		  
		  list = new ArrayList<Tuple2<String,String>>();
		  
		  Index index = db.getTable("news").getIndex("date-index");
		  QuerySpec spec = new QuerySpec()
				  	.withProjectionExpression("article, category")
				    .withKeyConditionExpression("#d = :v_date")
				    .withNameMap(new NameMap()
				        .with("#d", "date"))
				    .withValueMap(new ValueMap()
				        .withString(":v_date","2020-12-17"));
		  
		  itemsq = index.query(spec);
		  
		  //items = db.getTable("news").scan(null, "article, category", null, null);
		  
		  friendsi = itemsq.iterator();
		  while (friendsi.hasNext()) {
				Item temp = friendsi.next();
				list.add(new Tuple2<String,String>("c:" + temp.getString("category"), "a:" + temp.getString("article")));
				if (!singlelist.contains("c:"+temp.getString("category"))) {
					singlelist.add("c:" +temp.getString("category"));
				}

				singlelist2.add("a:" + temp.getString("article"));
				catmap.put("a:" + temp.getString("article"), "c:" +temp.getString("category"));
		  }
		  x.categories = list;
		  x.articlelist = singlelist2;
		  x.categorylist = singlelist;



		  
		  list = new ArrayList<Tuple2<String,String>>();
		  singlelist = new ArrayList<String>();
		  items = db.getTable("interests").scan(null,"interest, username",null,null);
		  friendsi = items.iterator();
		  while (friendsi.hasNext()) {
				Item temp = friendsi.next();
				list.add(new Tuple2<String,String>("u:" + temp.getString("username"), "c:" + temp.getString("interest")));
				if(!singlelist.contains("u:" +temp.getString("username"))) {
					singlelist.add("u:"+temp.getString("username"));
				}
		  }
		  x.userlist = singlelist;
		  x.interests = list;
		  
		  list = new ArrayList<Tuple2<String,String>>();
		  index = db.getTable("reactions").getIndex("date-index");
		  spec = new QuerySpec()
				  	.withProjectionExpression("username, article")
				    .withKeyConditionExpression("#d = :v_date")
				    .withNameMap(new NameMap()
				        .with("#d", "date"))
				    .withValueMap(new ValueMap()
				        .withString(":v_date","2020-12-17"));
		  itemsq = index.query(spec);
		  
		  //items = db.getTable("reactions").scan(null, "username, article", null, null);
		  
		  friendsi = itemsq.iterator();
		  while (friendsi.hasNext()) {
				Item temp = friendsi.next();
				list.add(new Tuple2<String,String>("u:" + temp.getString("username"), "a:" + temp.getString("article")));
				
		  }
		  x.likes = list;
		  
		  System.out.println(list);
		  
		  
		  List<MyPair<String, HashMap<String, Double>>> result = client.submit(x).get();

		  System.out.println("With backlinks: " + result);
		  HashSet<Item> temp = new HashSet<Item>();
		  boolean islike;
		  for (MyPair<String,HashMap<String,Double>> pair: result) {
			  for (Entry<String, Double> e: pair.getRight().entrySet()) {
				  islike = false;
				  for (Tuple2<String,String> lol: list) {
					  if ( lol._1.equals(e.getKey()) && lol._2.equals(pair.getLeft())) {
						  System.out.println("hey");
						  islike = true;
					  }
				  }
				  if (!islike) {
					  temp.add(new Item()
							  .withPrimaryKey("username", e.getKey(),"article",pair.getLeft())
							  .withString("category", catmap.get(pair.getLeft()))
							  .withDouble("weight", e.getValue()));
				  }


				  
			  }
		  }
		  TableWriteItems table;
			HashSet<Item> twentyfive = new HashSet<Item>();
			for (Item item:temp) {
				twentyfive.add(item);
				if (twentyfive.size() == 25) {
						try {
							table = new TableWriteItems("recommend");
							table.withItemsToPut(twentyfive);
							BatchWriteItemOutcome outcome = db.batchWriteItem(table);
							while (outcome.getUnprocessedItems().size() > 0) {
								Map<String, List<WriteRequest>> unprocessedItems = outcome.getUnprocessedItems();
								outcome = db.batchWriteItemUnprocessed(unprocessedItems);
							}
						} catch (Exception e){
							for (String y : e.getMessage().split(" ")) {
								if (y.equals("security")) {
									throw e;
								}
							}
							System.out.println(e);
						} 
					twentyfive.clear();
				}
			}
			if (twentyfive.size() > 0) {
				table = new TableWriteItems("recommend");
				table.withItemsToPut(twentyfive);
				db.batchWriteItem(table);
			}
			System.out.println("done");
		  try
		  {
		      Thread.sleep(10000);
		  }
		  catch(InterruptedException ex)
		  {
		      Thread.currentThread().interrupt();
		  }
		  
		  
		} finally {
		  client.stop(true);
		}
	}
}
