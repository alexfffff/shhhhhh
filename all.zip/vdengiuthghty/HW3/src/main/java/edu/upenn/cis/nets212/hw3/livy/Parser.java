package edu.upenn.cis.nets212.hw3.livy;

import java.io.BufferedReader;
import java.io.FileReader;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.BatchWriteItemOutcome;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.TableWriteItems;
import com.amazonaws.services.dynamodbv2.model.WriteRequest;
import com.fasterxml.jackson.databind.ObjectMapper;

import edu.upenn.cis.nets212.config.Config;
import opennlp.tools.stemmer.PorterStemmer;
import opennlp.tools.stemmer.Stemmer;
import opennlp.tools.tokenize.SimpleTokenizer;

public class Parser {
	static String add4(String date) {
		String temp = Integer.toString(Integer.parseInt(date.substring(0,4)) + 4);

		return temp + date.substring(4, date.length());
	}
	
	static int compare(String date1, String date2) {
		Integer x=Integer.parseInt(date1.substring(0,4));
		Integer y=Integer.parseInt(date2.substring(0,4));
		if (x.compareTo(y) == (Integer)0) {
			x = Integer.parseInt(date1.substring(5,7));
			y = Integer.parseInt(date2.substring(5,7));
			if (x.compareTo(y) == (Integer)0) {
				x = Integer.parseInt(date1.substring(8,10));
				y = Integer.parseInt(date2.substring(8,10));
				return x.compareTo(y);
			} else {
				return x.compareTo(y);
			}
		} else {
			return x.compareTo(y);
		}
	}
	public static void main(String[] args) {
		BufferedReader reader;
		SimpleTokenizer model;
		Stemmer stemmer;
		DynamoDB db;
		Table articles;
		Table inverted;
		

		
		model = SimpleTokenizer.INSTANCE;
		stemmer = new PorterStemmer();
		AmazonDynamoDB clientd = AmazonDynamoDBClientBuilder.standard().build();
		db = new DynamoDB(clientd);
		articles = db.getTable("news");
		inverted = db.getTable("inverted");
		HashSet<Item> temp = new HashSet<Item>();
		HashSet<Item> temp2 = new HashSet<Item>();
		HashSet<String> stopwords = new HashSet<String>();
		System.out.println("stopwords");
		try {
			reader = new BufferedReader(new FileReader("target/News_Category_Dataset_v2.json"));
			String line = reader.readLine();
			System.out.println("starting");
		    ObjectMapper mapper = new ObjectMapper();
		    Map books;
			try{
				BufferedReader j = new BufferedReader(new FileReader("src/main/resources/nlp_en_stop_words.txt")); 
				Boolean go = true;

				while (go) {
					String temp3 = j.readLine();
					if(temp3 == null) {
						go = false;
					} else {
						stopwords.add(temp3);
					}
					
				}
				j.close();
			} catch( Exception e) {
				System.out.println("oh no");
			}
			System.out.println("starting parsing");
			HashSet<String> interests = new HashSet<String>();
			while (line !=null) {
			    books = mapper.readValue(line,Map.class);
			    // print books
			    interests.add((String)books.get("category"));
			    if (compare(add4((String)books.get("date")),"2020-12-17") <= 0 && compare(add4((String)books.get("date")),"2020-11-17") >= 0) {
					System.out.println(add4((String)books.get("date")));
				    String title = (String)books.get("headline");
				    String[] x = title.split(" ");
				    
				    HashSet<String> wordset = new HashSet<String>();
				    for (String word: x) {
						if (word.chars().allMatch(Character::isLetter)) {
							word = word.toLowerCase();
							Boolean isstopwrod = false;
							for (String stopword:stopwords) {
								if (word.equals(stopword)) {
									 isstopwrod = true;
								}
							}
							if (!isstopwrod) {
								String s = stemmer.stem(word).toString();
								if (s.length() == 0) {
									
								} else {
									if (!wordset.contains(s)) {
										wordset.add(s);
										temp2.add(new Item()
														.withPrimaryKey("keyword",s,"article",books.get("headline").toString())
										);
									}
								}

								
							}
						}
				    }
				    temp.add(new Item()
							.withPrimaryKey("article",books.get("headline"))
							.withString("category",(String)books.get("category"))
							.withString("authors",(String)books.get("authors"))
							.withString("description",(String)books.get("short_description"))
							.withString("date",add4((String)books.get("date")))
							.withString("link",(String)books.get("link")));
				    
			    }

			    line = reader.readLine();
			}
			reader.close();
			System.out.println("starting to put into database");
			System.out.println(temp.size());
			Integer count = 0;
			TableWriteItems table;
			HashSet<Item> twentyfive = new HashSet<Item>();
			
			for (Item item:temp) {
				if (item.get("article") != null) {
					twentyfive.add(item);
				} 
				if (twentyfive.size() == 25) {
					//if(count > 3993) {
					if (count > -1) {
						try {
							table = new TableWriteItems("news");
							table.withItemsToPut(twentyfive);
							BatchWriteItemOutcome outcome = db.batchWriteItem(table);
							while (outcome.getUnprocessedItems().size() > 0) {
								Map<String, List<WriteRequest>> unprocessedItems = outcome.getUnprocessedItems();
								outcome = db.batchWriteItemUnprocessed(unprocessedItems);
							}
						} catch (Exception e){
							for (String x : e.getMessage().split(" ")) {
								if (x.equals("security")) {
									throw e;
								}
							}
							System.out.println(e);
						} 

					}
					count++;
					System.out.println(count);
					twentyfive.clear();
				}
			}
			if (twentyfive.size() > 0) {
				table = new TableWriteItems("news");
				table.withItemsToPut(twentyfive);
				db.batchWriteItem(table);
			}
			twentyfive.clear();
			System.out.println("finished first starting second");
			count = 0;
			for (Item item:temp2) {
				twentyfive.add(item);
				if (twentyfive.size() == 25) {
					//if(count > 5050) {
					if (count > -1 ) {
						try {
							table = new TableWriteItems("inverted");
							table.withItemsToPut(twentyfive);
							BatchWriteItemOutcome outcome = db.batchWriteItem(table);
							while (outcome.getUnprocessedItems().size() > 0) {
								Map<String, List<WriteRequest>> unprocessedItems = outcome.getUnprocessedItems();
								outcome = db.batchWriteItemUnprocessed(unprocessedItems);
							}
						} catch (Exception e){
							for (String x : e.getMessage().split(" ")) {
								if (x.equals("security")) {
									throw e;
								}
							}
							System.out.println(e);
						} 
					}
					count++;
					System.out.println(count);
					twentyfive.clear();
				}
			}
			if (twentyfive.size() > 0) {
				table = new TableWriteItems("inverted");
				table.withItemsToPut(twentyfive);
				db.batchWriteItem(table);
			}
			System.out.println("rinished");
			System.out.println(interests.toString());
		    //reader.close();
		} catch (Exception ex) {
		    ex.printStackTrace();
		}
	}
}
