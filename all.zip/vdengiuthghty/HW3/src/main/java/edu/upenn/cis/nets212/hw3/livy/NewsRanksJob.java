package edu.upenn.cis.nets212.hw3.livy;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import org.apache.livy.Job;
import org.apache.livy.JobContext;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.sql.SparkSession;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.ScanOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;

import edu.upenn.cis.nets212.config.Config;
import edu.upenn.cis.nets212.storage.SparkConnector;
import scala.Tuple2;
import software.amazon.awssdk.services.dynamodb.model.DynamoDbException;



public class NewsRanksJob implements Job<List<MyPair<String, HashMap<String, Double>>>>{

	
	SparkSession spark;
	
	public ArrayList<Tuple2<String,String>> friends;
	public ArrayList<Tuple2<String,String>> categories;
	public ArrayList<Tuple2<String,String>> likes;
	public ArrayList<Tuple2<String,String>> interests;
	
	public ArrayList<String> userlist;
	public ArrayList<String> categorylist;
	public ArrayList<String> articlelist;
	
	
	public JavaPairRDD<String, String> UsersToCategory;
	public JavaPairRDD<String, String> CategoryToNews;
	public JavaPairRDD<String, String> UsersToUsers;
	public JavaPairRDD<String, String> UsersToArticles;
	
	JavaSparkContext context;
	
	static Integer maxIters = 15;
	
	private boolean useBacklinks;

	private String source;
	
	
	public void initialize() throws IOException, InterruptedException {
		System.out.println("Connecting to Spark...");
		spark = SparkConnector.getSparkConnection();
		context = SparkConnector.getSparkContext();
		UsersToUsers = context.parallelize(friends).mapToPair(f-> f);
		CategoryToNews = context.parallelize(categories).mapToPair(f->f);
		UsersToArticles = context.parallelize(likes).mapToPair(f->f);
		UsersToCategory = context.parallelize(interests).mapToPair(f->f);
		
		System.out.println("Connected!");
	}
	
	HashMap<String,Double> createMap(String id ){
		HashMap<String,Double> x = new HashMap<String,Double>();
		x.put(id, 1.0);
		return x;
	}
	HashMap<String,Double> multiply(HashMap<String,Double> x, double factor) {
		HashMap<String,Double> y = new HashMap<String,Double>();
		x.entrySet().stream().forEach(e-> y.put(e.getKey(), factor * e.getValue()));
		return y;
	}
 	public List<MyPair<String, HashMap<String, Double>>> run() throws IOException, InterruptedException {
 		
		System.out.println("Running");
		//creating edges
		JavaPairRDD<String,String> CategoryToUsers = UsersToCategory.mapToPair(new SwapKeyValue<String,String>());
		JavaPairRDD<String,String> NewsToCategory = CategoryToNews.mapToPair(new SwapKeyValue<String,String>());
		JavaPairRDD<String,String> NewsToUsers = UsersToArticles.mapToPair(new SwapKeyValue<String,String>());
		
		CategoryToNews = CategoryToNews.union(CategoryToUsers);
		
		NewsToCategory = NewsToCategory.union(NewsToUsers);
		
		Map<String,Long> u2cmap = UsersToCategory.countByKey();
		Map<String,Long> u2umap = UsersToUsers.countByKey();
		Map<String,Long> u2amap = UsersToArticles.countByKey();
		Map<String,Long> c2amap = CategoryToNews.countByKey();
		Map<String,Long> a2cmap = NewsToCategory.countByKey();
		
		JavaPairRDD<String,Tuple2<String,Double>> edges1  = UsersToCategory.mapToPair(f -> 
								new Tuple2<String,Tuple2<String,Double>>(f._1,new Tuple2<String,Double>(f._2, 0.3/u2cmap.get(f._1) )));
		JavaPairRDD<String,Tuple2<String,Double>> edges2  = UsersToUsers.mapToPair(f -> 
								new Tuple2<String,Tuple2<String,Double>>(f._1,new Tuple2<String,Double>(f._2, 0.3/u2umap.get(f._1) )));
		JavaPairRDD<String,Tuple2<String,Double>> edges3  = UsersToArticles.mapToPair(f -> 
								new Tuple2<String,Tuple2<String,Double>>(f._1,new Tuple2<String,Double>(f._2, 0.4/u2amap.get(f._1) )));
		JavaPairRDD<String,Tuple2<String,Double>> edges4  = CategoryToNews.mapToPair(f -> 
								new Tuple2<String,Tuple2<String,Double>>(f._1,new Tuple2<String,Double>(f._2, 1.0/c2amap.get(f._1) )));
		JavaPairRDD<String,Tuple2<String,Double>> edges5  = NewsToCategory.mapToPair(f -> 
								new Tuple2<String,Tuple2<String,Double>>(f._1,new Tuple2<String,Double>(f._2, 1.0/a2cmap.get(f._1) )));

		
		JavaPairRDD<String,Tuple2<String,Double>> edges = edges1.union(edges2);
		edges = edges.union(edges3);
		edges = edges.union(edges4);
		edges = edges.union(edges5);
		
		JavaRDD<String> articles = context.parallelize(articlelist);
		JavaRDD<String> users = context.parallelize(userlist);
		JavaRDD<String> category = context.parallelize(categorylist); 
		
		JavaPairRDD<String,Integer> onlyArticles = articles.mapToPair(f-> new Tuple2<String, Integer>(f, 1));


		System.out.println("creating nodes");
		JavaPairRDD<String, Long> index = users.zipWithIndex();
		JavaPairRDD<String,HashMap<String,Double>> nodes1 = index.mapToPair(f-> {
			HashMap<String,Double> x = new HashMap<String,Double>();
			x.put(f._1, 1.0);
			return new Tuple2<String,HashMap<String,Double>>(f._1, x);
		});
		JavaPairRDD<String,HashMap<String,Double>> nodes2 = category.mapToPair(f-> new Tuple2<String,HashMap<String,Double>>(f, new HashMap<String,Double>()));
		JavaPairRDD<String,HashMap<String,Double>> nodes3 = articles.mapToPair(f-> new Tuple2<String,HashMap<String,Double>>(f, new HashMap<String,Double>()));
		
		JavaPairRDD<String,Integer> notUsers = category.mapToPair(f-> new Tuple2<String,Integer>(f,1));
		notUsers = notUsers.union(articles.mapToPair(f-> new Tuple2<String,Integer>(f,1)));
		
		JavaPairRDD<String,HashMap<String,Double>> nodes = nodes1.union(nodes2);
		nodes = nodes.union(nodes3);
		
		System.out.println("doing 15 iterations ");
		for (int i = 0; i < maxIters; i++) {
			System.out.println(i);
			// nodeid, ((destnode, weight),array of values)
			JavaPairRDD<String,HashMap<String,Double>> propogate = edges.join(nodes)
					.mapToPair(f -> {
						HashMap<String,Double> y = new HashMap<String,Double>();
						f._2._2.entrySet().stream().forEach(e-> y.put(e.getKey(), f._2._1._2 * e.getValue()));
						return new Tuple2<String,HashMap<String,Double>>(f._2._1._1, y);
					});
			JavaPairRDD<String,HashMap<String,Double>> added = propogate.reduceByKey((a,b)-> {
				a.forEach((k,v)-> b.merge(k, v, (v1,v2)-> v1+v2));
				return (HashMap<String,Double>)b.entrySet()
						.stream()
						.filter(map -> map.getValue() > 0.05)
						.collect(Collectors.toMap(map -> (String)map.getKey(), map -> (Double)map.getValue()));
			}); 
			
			JavaPairRDD<String,Double> total = added.mapToPair(f -> new Tuple2<String,Double>(f._1,f._2.values().stream().mapToDouble(n -> n.doubleValue()).sum()));
			// nodeid, (total, array)
			nodes = total.join(added).mapToPair(f -> {
				HashMap<String,Double> y = new HashMap<String,Double>();
				f._2._2.entrySet().stream().forEach(e-> y.put(e.getKey(), 1/f._2._1 * e.getValue()));
				return new Tuple2<String,HashMap<String,Double>>(f._1, y);
			});
			//nodes = notUsers.join(nodes).mapToPair(f->new Tuple2<String,HashMap<String,Double>>(f._1,f._2._2)).union(nodes1);
			//nodeid, (empty, maybe full)
			
		}
		JavaPairRDD<String, Tuple2<Integer, HashMap<String, Double>>> result = onlyArticles.join(nodes);
		List<MyPair<String,HashMap<String,Double>>> ret = new ArrayList<MyPair<String,HashMap<String,Double>>>();
		for (Tuple2<String, Tuple2<Integer, HashMap<String, Double>>> tuple: result.collect()) {
			ret.add(new MyPair<String, HashMap<String,Double>>(tuple._1,tuple._2._2));
		}
		return ret;
 	}
	
	public NewsRanksJob() {
		System.setProperty("file.encoding", "UTF-8");

	}
	public void shutdown() {
		System.out.println("Shutting down");
	}
	// thank you for writing this last time, 
	//author: Zach Ives
	static class SwapKeyValue<T1,T2> implements PairFunction<Tuple2<T1,T2>, T2,T1> {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Override
		public Tuple2<T2, T1> call(Tuple2<T1, T2> t) throws Exception {
			return new Tuple2<>(t._2, t._1);
		}
		
	}
	
	@Override
	public List<MyPair<String, HashMap<String, Double>>> call(JobContext arg0) throws Exception {
		initialize();
		return run();
	}
	
}

