package edu.upenn.cis.nets212.hw3.livy;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutionException;

import org.apache.livy.LivyClient;
import org.apache.livy.LivyClientBuilder;

import edu.upenn.cis.nets212.config.Config;

public class ComputeRanksLivy {
	public static void main(String[] args) throws IOException, URISyntaxException, InterruptedException, ExecutionException {
		
		// default values if no arguments provided
		double deltaMax = 30.0;
		int iterMax = 25;
		boolean debugMode = false;
		
		// arguments to take in
		if (args.length > 0) {
			deltaMax = Double.parseDouble(args[0]);
			if (args.length > 1) {
				iterMax = Integer.parseInt(args[1]);
				if (args.length > 2) {
					System.out.println("Entering debug mode...");
					debugMode = true;
				}
			}
		}
		
		LivyClient client = new LivyClientBuilder()
				  .setURI(new URI("http://ec2-##-###-###-##.compute-1.amazonaws.com:8998"))
				  .build();

		try {
			String jar = "target/nets212-hw3-0.0.1-SNAPSHOT.jar";
			
		  System.out.printf("Uploading %s to the Spark context...\n", jar);
		  client.uploadJar(new File(jar)).get();
		  
		  String sourceFile = Config.BIGGER_SOCIAL_NET_PATH;

		  System.out.printf("Running SocialRankJob with %s as its input...\n", sourceFile);
		  
		  List<MyPair<Integer, Double>> result = client.submit(
				  new SocialRankJob(true, sourceFile, deltaMax, iterMax, debugMode)).get();
		  System.out.println("With backlinks: " + result);

		  // TODO write the output to a file that you'll upload.
		  
		  List<MyPair<Integer, Double>> noBacklinks = client.submit(
				  new SocialRankJob(false, sourceFile, deltaMax, iterMax, debugMode)).get();
		  System.out.println("Without backlinks: " + noBacklinks);
		  
		  // output Strings that will be modified to account for each node
		  String common = "";
		  String backlinkOnly = "";
		  String noBacklinkOnly = "";
		  
		  // put all of the nodes in the "with backlink" result into a set
		  Set<Integer> backlinkNodes = new HashSet<Integer>();
		  for (MyPair<Integer, Double> p : result) {
			  backlinkNodes.add(p.getLeft());
		  }
		  
		  // iterate over the list of pairs in the "without backlink" computation
		  for (MyPair<Integer, Double> p : noBacklinks) {
			  // if the node is present in both, add it to the common nodes
			  if (backlinkNodes.contains(p.getLeft())) {
				  common += (p.getLeft().toString() + ", ");
				  // remove it from backlinkNodes so that set can have exclusively backlink nodes
				  backlinkNodes.remove(p.getLeft());
			  } else {
				  // node is present only in result without backlinks
				  noBacklinkOnly += (p.getLeft().toString() + ", ");
			  }
		  }
		  
		  // iterate over updated backlinkNodes that contains nodes exclusive to that computation
		  for (Integer b : backlinkNodes) {
			  backlinkOnly += (b.toString() + ", ");
		  }
		  
		  if (common.length() > 2) {
			  System.out.println("Nodes in common: " + common.substring(0, common.length() - 2));
		  } else {
			  System.out.println("No nodes in common");
		  }
		  
		  if (backlinkOnly.length() > 2) {
			  System.out.println("Nodes exclusive to the computation with back-links: " + 
					  backlinkOnly.substring(0, backlinkOnly.length() - 2));
		  } else {
			  System.out.println("No nodes exclusive to the computation with back-links");
		  }
		  
		  if (noBacklinkOnly.length() > 2) {
			  System.out.println("Nodes exclusive to the computation without back-links: " + 
					  noBacklinkOnly.substring(0, noBacklinkOnly.length() - 2));
		  } else {
			  System.out.println("No nodes exclusive to the computation without back-links");
		  }
		  
		} finally {
		  client.stop(true);
		}
	}

}
