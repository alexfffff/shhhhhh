package edu.upenn.cis.nets212.hw3.livy;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.apache.livy.Job;
import org.apache.livy.JobContext;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.sql.SparkSession;

import edu.upenn.cis.nets212.config.Config;
import edu.upenn.cis.nets212.storage.SparkConnector;
import scala.Tuple2;
import software.amazon.awssdk.services.dynamodb.model.DynamoDbException;

public class SocialRankJob implements Job<List<MyPair<Integer,Double>>> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Connection to Apache Spark
	 */
	SparkSession spark;
	
	JavaSparkContext context;

	private boolean useBacklinks;

	private String source;
	
	/**
	 * Helper function: swap key and value in a JavaPairRDD
	 * 
	 * @author zives
	 *
	 */
	static class SwapKeyValue<T1,T2> implements PairFunction<Tuple2<T1,T2>, T2,T1> {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Override
		public Tuple2<T2, T1> call(Tuple2<T1, T2> t) throws Exception {
			return new Tuple2<>(t._2, t._1);
		}
		
	}
	
	private double deltaMax;
	private int iterMax;
	private boolean debugMode;

	/**
	 * Initialize the database connection and open the file
	 * 
	 * @throws IOException
	 * @throws InterruptedException 
	 * @throws DynamoDbException 
	 */
	public void initialize() throws IOException, InterruptedException {
		System.out.println("Connecting to Spark...");
		spark = SparkConnector.getSparkConnection();
		context = SparkConnector.getSparkContext();
		
		System.out.println("Connected!");
	}
	
	/**
	 * Fetch the social network from the S3 path, and create a (followed, follower) edge graph
	 * 
	 * @param filePath
	 * @return JavaPairRDD: (followed: int, follower: int)
	 */
	JavaPairRDD<Integer,Integer> getSocialNetwork(String filePath) {
		// TODO Your code from ComputeRanks here
		
		// read into RDD with lines as strings, split by spaces or tab characters
		JavaRDD<String[]> file = context.textFile(filePath, Config.PARTITIONS)
				.map(line -> line.toString().split(" |\\t"));
		
		// number of elements present in the RDD is the number of edges
		long edges = file.count();
		
		// map data (follower, followed) to key/value with (followed, follower)
		JavaPairRDD<Integer, Integer> network = 
				file.mapToPair(s -> new Tuple2<Integer,Integer>(Integer.valueOf(s[1]), Integer.valueOf(s[0])));
		
		// union the followers and followed, then count the total number of distinct nodes
		long nodes = network.keys().union(network.values()).distinct().count();
		
		System.out.println("This graph contains " + nodes + " nodes and " + edges + " edges");
		
		return network;
	}
	
	private JavaRDD<Integer> getSinks(JavaPairRDD<Integer,Integer> network) {
		// TODO Your code from ComputeRanks here
		
		// subtract set of followers from the set of followed to get all nodes that do not follow anyone
		return network.keys().distinct().subtract(network.values().distinct());
	}

	/**
	 * Main functionality in the program: read and process the social network
	 * 
	 * @throws IOException File read, network, and other errors
	 * @throws DynamoDbException DynamoDB is unhappy with something
	 * @throws InterruptedException User presses Ctrl-C
	 */
	public List<MyPair<Integer,Double>> run() throws IOException, InterruptedException {
		System.out.println("Running");

		// Load the social network (followed, follower)
		JavaPairRDD<Integer, Integer> network = getSocialNetwork(source);
		
		// TODO Your code from ComputeRanks here
		
		// only add backlinks if the argument is true
		if (useBacklinks) {
			// create HashSet of sinks for fast contains method
			HashSet<Integer> sinks = new HashSet<Integer>(getSinks(network).collect());
			
			// reverse the direction of edges in the graph, then filter to keep only the outgoing edges of sinks
			JavaPairRDD<Integer,Integer> reversed = network.mapToPair(new SwapKeyValue<Integer,Integer>());
			JavaPairRDD<Integer,Integer> backlinks = reversed.filter(t -> sinks.contains(t._2));
			
			// union the backlinks with the old network and update the network
			JavaPairRDD<Integer, Integer> newNetwork = network.union(backlinks);
			network = newNetwork;
			
			System.out.println("Added " + backlinks.count() + " backlinks");
		}
		
		double decay = 0.15;
		
		// swap (followed, follower) to (follower, followed))
		network = network.mapToPair(new SwapKeyValue<Integer, Integer>());
		
		// initialize the SocialRank with a value of 1 at all nodes
		JavaPairRDD<Integer, Double> ranks = network.mapToPair(t -> {
			return new Tuple2<Integer, Double>(t._2, 1.0);
		}).distinct();
		
		// assign weight to each backlink (b, 1/N_b)
		JavaPairRDD<Integer, Double> nodeTransferRDD = network
				.mapToPair(t -> new Tuple2<Integer, Double>(t._1, 1.0)) // follower, 1.0
				.reduceByKey((a, b) -> a + b) // N_b, cardinality of the set of vertices whom b follows
				.mapToPair(t -> new Tuple2<Integer, Double>(t._1, 1.0 / t._2)); // take reciprocal
		
		// join the two RDDs together by key [b, (p, 1/N_b)]
		JavaPairRDD<Integer, Tuple2<Integer, Double>> edgeTransferRDD = network.join(nodeTransferRDD);
		
		// outputs a list of node IDs and their SocialRanks after initial round in debug mode
		if (debugMode) {
			System.out.println("Initialization round complete. Here are the results.");
			ranks.foreach(t -> {
				System.out.println("" + t._1 + " " + t._2);
			});
		}
		
		// stop computing after iterMax iterations have passed
		for (int iterations = 0; iterations < iterMax; iterations++) {
			JavaPairRDD<Integer, Double> propagateRDD = edgeTransferRDD
					.join(ranks) // (b, [(p, 1/N_b), SR(b)])
					.mapToPair(t -> {
						// (p, SR(b) * 1/N_b)
						return new Tuple2<Integer, Double>(t._2._1._1, t._2._2 * t._2._1._2);
					});
			
			JavaPairRDD<Integer, Double> newRanks = propagateRDD
					.reduceByKey((x, y) -> x + y) // (p, sum of propagation)
					.mapToPair(t -> {
						// add decay factor
						return new Tuple2<Integer, Double>(t._1, decay + ((1.0 - decay) * t._2));
					});
			
			// outputs a list of node IDs and their SocialRanks after each round in debug mode
			if (debugMode) {
				System.out.println("Round " + iterations + " complete. Here are the results.");
				newRanks.foreach(t -> {
					System.out.println("" + t._1 + " " + t._2);
				});
			}
			
			// join previous ranks with new ranks and consider the ranks only, get the largest change
			double deltaLargest = ranks.join(newRanks).map(t -> {
				return Math.abs(t._2._1 - t._2._2); // compute change in rank per node, map to a double
			}).distinct().aggregate(0.0, // aggregate function to find the max in the RDD of deltas
					(a, value) -> value, 
					(x, y) -> Math.max(x, y));
						
			// update the new social ranks
			ranks = newRanks;
			
			if (deltaLargest <= deltaMax) {
				break;
			}
		}
		
		List<MyPair<Integer, Double>> highestSocialRanks = new ArrayList<MyPair<Integer, Double>>();
		
		// get the top 10 nodes with the highest SocialRank values, with the SocialRank of each
		JavaPairRDD<Double, Integer> ranksByID = ranks.mapToPair(new SwapKeyValue<Integer, Double>());
		ranksByID = ranksByID.sortByKey(false, Config.PARTITIONS);
		for (Tuple2<Double, Integer> tuple : ranksByID.take(10)) {
			// add the node and its social rank to the list as a MyPair
			highestSocialRanks.add(new MyPair<Integer, Double>(tuple._2, tuple._1));
		}
		
		System.out.println("*** Finished social network ranking! ***");
		
		return highestSocialRanks;
	}

	/**
	 * Graceful shutdown
	 */
	public void shutdown() {
		System.out.println("Shutting down");
	}
	
	public SocialRankJob(boolean useBacklinks, String source, double d, int i, boolean debug) {
		System.setProperty("file.encoding", "UTF-8");
		
		this.useBacklinks = useBacklinks;
		this.source = source;
		
		// arguments to take in
		this.deltaMax = d;
		this.iterMax = i;
		this.debugMode = debug;
	}

	@Override
	public List<MyPair<Integer,Double>> call(JobContext arg0) throws Exception {
		initialize();
		return run();
	}

}
