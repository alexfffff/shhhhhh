package edu.upenn.cis.nets212.hw3;

import java.io.IOException;
import java.util.HashSet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.sql.SparkSession;

import edu.upenn.cis.nets212.config.Config;
import edu.upenn.cis.nets212.storage.SparkConnector;
import scala.Tuple2;

public class ComputeRanks {
	/**
	 * The basic logger
	 */
	static Logger logger = LogManager.getLogger(ComputeRanks.class);

	/**
	 * Connection to Apache Spark
	 */
	SparkSession spark;
	
	JavaSparkContext context;
	
	public ComputeRanks() {
		System.setProperty("file.encoding", "UTF-8");
	}
	
	/**
	 * Helper function: swap key and value in a JavaPairRDD
	 * 
	 * @author zives
	 *
	 */
	static class SwapKeyValue<T1,T2> implements PairFunction<Tuple2<T1,T2>, T2,T1> {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Override
		public Tuple2<T2, T1> call(Tuple2<T1, T2> t) throws Exception {
			return new Tuple2<>(t._2, t._1);
		}
		
	}
	
	static double deltaMax = 30.0;
	static int iterMax = 25;
	static boolean debugMode = false;

	/**
	 * Initialize the database connection and open the file
	 * 
	 * @throws IOException
	 * @throws InterruptedException 
	 */
	public void initialize() throws IOException, InterruptedException {
		logger.info("Connecting to Spark...");

		spark = SparkConnector.getSparkConnection();
		context = SparkConnector.getSparkContext();
		
		logger.debug("Connected!");
	}
	
	/**
	 * Fetch the social network from the S3 path, and create a (followed, follower) edge graph
	 * 
	 * @param filePath
	 * @return JavaPairRDD: (followed: int, follower: int)
	 */
	JavaPairRDD<Integer,Integer> getSocialNetwork(String filePath) {
		// TODO Load the file filePath into an RDD (take care to handle both spaces and tab characters as separators)
		
		// read into RDD with lines as strings, split by spaces or tab characters
		JavaRDD<String[]> file = context.textFile(filePath, Config.PARTITIONS)
				.map(line -> line.toString().split(" |\\t"));
		
		// number of elements present in the RDD is the number of edges
		long edges = file.count();
		
		// map data (follower, followed) to key/value with (followed, follower)
		JavaPairRDD<Integer, Integer> network = 
				file.mapToPair(s -> new Tuple2<Integer,Integer>(Integer.valueOf(s[1]), Integer.valueOf(s[0])));
		
		// union the followers and followed, then count the total number of distinct nodes
		long nodes = network.keys().union(network.values()).distinct().count();
		
		logger.info("This graph contains " + nodes + " nodes and " + edges + " edges");
		
		return network;
	}
	
	private JavaRDD<Integer> getSinks(JavaPairRDD<Integer,Integer> network) {
		// TODO Find the sinks in the provided graph
		
		// subtract set of followers from the set of followed to get all nodes that do not follow anyone
		return network.keys().distinct().subtract(network.values().distinct());
	}

	/**
	 * Main functionality in the program: read and process the social network
	 * 
	 * @throws IOException File read, network, and other errors
	 * @throws InterruptedException User presses Ctrl-C
	 */
	public void run() throws IOException, InterruptedException {
		logger.info("Running");

		// Load the social network (followed, follower)
		JavaPairRDD<Integer, Integer> network = getSocialNetwork(Config.SOCIAL_NET_PATH);
		
	    // TODO find the sinks
	    // TODO add back-edges
		
		// create HashSet of sinks for fast contains method
		HashSet<Integer> sinks = new HashSet<Integer>(getSinks(network).collect());
		
		// reverse the direction of edges in the graph, then filter to keep only the outgoing edges of sinks
		JavaPairRDD<Integer,Integer> reversed = network.mapToPair(new SwapKeyValue<Integer,Integer>());
		JavaPairRDD<Integer,Integer> backlinks = reversed.filter(t -> sinks.contains(t._2));
		
		// union the backlinks with the old network and update the network
		JavaPairRDD<Integer, Integer> newNetwork = network.union(backlinks);
		network = newNetwork;
		
		logger.info("Added " + backlinks.count() + " backlinks");
		
		double decay = 0.15;
		
		// swap (followed, follower) to (follower, followed))
		network = network.mapToPair(new SwapKeyValue<Integer, Integer>());
		
		// initialize the SocialRank with a value of 1 at all nodes
		JavaPairRDD<Integer, Double> ranks = network.mapToPair(t -> {
			return new Tuple2<Integer, Double>(t._2, 1.0);
		}).distinct();
		
		// assign weight to each backlink (b, 1/N_b)
		JavaPairRDD<Integer, Double> nodeTransferRDD = network
				.mapToPair(t -> new Tuple2<Integer, Double>(t._1, 1.0)) // follower, 1.0
				.reduceByKey((a, b) -> a + b) // N_b, cardinality of the set of vertices whom b follows
				.mapToPair(t -> new Tuple2<Integer, Double>(t._1, 1.0 / t._2)); // take reciprocal
		
		// join the two RDDs together by key [b, (p, 1/N_b)]
		JavaPairRDD<Integer, Tuple2<Integer, Double>> edgeTransferRDD = network.join(nodeTransferRDD);
		
		// outputs a list of node IDs and their SocialRanks after initial round in debug mode
		if (debugMode) {
			logger.info("Initialization round complete. Here are the results.");
			ranks.foreach(t -> {
				logger.info("" + t._1 + " " + t._2);
			});
		}
		
		// stop computing after iterMax iterations have passed
		for (int iterations = 0; iterations < iterMax; iterations++) {
			JavaPairRDD<Integer, Double> propagateRDD = edgeTransferRDD
					.join(ranks) // (b, [(p, 1/N_b), SR(b)])
					.mapToPair(t -> {
						// (p, SR(b) * 1/N_b)
						return new Tuple2<Integer, Double>(t._2._1._1, t._2._2 * t._2._1._2);
					});
			
			JavaPairRDD<Integer, Double> newRanks = propagateRDD
					.reduceByKey((x, y) -> x + y) // (p, sum of propagation)
					.mapToPair(t -> {
						// add decay factor
						return new Tuple2<Integer, Double>(t._1, decay + ((1.0 - decay) * t._2));
					});
			
			// outputs a list of node IDs and their SocialRanks after each round in debug mode
			if (debugMode) {
				logger.info("Round " + iterations + " complete. Here are the results.");
				newRanks.foreach(t -> {
					logger.info("" + t._1 + " " + t._2);
				});
			}
			
			// join previous ranks with new ranks and consider the ranks only, get the largest change
			double deltaLargest = ranks.join(newRanks).map(t -> {
				return Math.abs(t._2._1 - t._2._2); // compute change in rank per node, map to a double
			}).distinct().aggregate(0.0, // aggregate function to find the max in the RDD of deltas
					(a, value) -> value, 
					(x, y) -> Math.max(x, y));
			
			// update the new social ranks
			ranks = newRanks;
			
			if (deltaLargest <= deltaMax) {
				break;
			}
		}
		
		// output the 10 nodes with the highest SocialRank values, with the SocialRank value of each
		logger.info("Here are the 10 node IDs with the highest SocialRank values:");
		JavaPairRDD<Double, Integer> ranksByID = ranks.mapToPair(new SwapKeyValue<Integer, Double>());
		ranksByID = ranksByID.sortByKey(false, Config.PARTITIONS);
		for (Tuple2<Double, Integer> tuple : ranksByID.take(10)) {
			logger.info("" + tuple._2 + " " + tuple._1);
		}
		
		logger.info("*** Finished social network ranking! ***");
	}


	/**
	 * Graceful shutdown
	 */
	public void shutdown() {
		logger.info("Shutting down");

		if (spark != null)
			spark.close();
	}
	
	

	public static void main(String[] args) {
		final ComputeRanks cr = new ComputeRanks();
		
		// accept and parse possible command-line arguments
		if (args.length > 0) {
			deltaMax = Double.parseDouble(args[0]);
			if (args.length > 1) {
				iterMax = Integer.parseInt(args[1]);
				if (args.length > 2) {
					logger.info("Entering debug mode...");
					debugMode = true;
				}
			}
		}

		try {
			cr.initialize();

			cr.run();
		} catch (final IOException ie) {
			logger.error("I/O error: ");
			ie.printStackTrace();
		} catch (final InterruptedException e) {
			e.printStackTrace();
		} finally {
			cr.shutdown();
		}
	}

}
